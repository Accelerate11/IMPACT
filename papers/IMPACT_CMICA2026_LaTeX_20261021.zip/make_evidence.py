#!/usr/bin/env python3
"""Export paper plotting data from completed, immutable experiment outputs."""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1048576),b''):h.update(block)
    return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}


def rows(path):
    with path.open() as handle:
        for line in handle:yield json.loads(line)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--workspace',type=Path,required=True)
    parser.add_argument('--full-run',type=Path,required=True);parser.add_argument('--controls-run',type=Path,required=True)
    parser.add_argument('--truth',type=Path,required=True);parser.add_argument('--controls-evaluation',type=Path,required=True)
    parser.add_argument('--full-evaluation',type=Path,required=True)
    args=parser.parse_args();target=ROOT/'evidence';target.mkdir(exist_ok=True)
    sys.path.insert(0,str(args.workspace/'scripts'))
    from analyze_livo_replay import align_and_measure
    sources={}
    def bind(path):sources[str(path)]=digest(path)
    full_manifest=args.full_run/'configuration/joint-build-manifest.json'
    control_manifest=args.controls_run/'configuration/joint-build-manifest.json'
    if json.loads(full_manifest.read_text())!=json.loads(control_manifest.read_text()):
        raise ValueError('Different installed binary/source/dependency manifests')
    indices=[run/'input/sensor-index.json' for run in (args.full_run,args.controls_run)]
    if digest(indices[0])!=digest(indices[1]):raise ValueError('Different source acquisition index')
    truth=list(rows(args.truth));truth_times=[value['stamp_s'] for value in truth]
    truth_positions=np.asarray([value['position'] for value in truth])
    data={'arms':{},'truth':{'stamps_s':truth_times,'position':truth_positions.tolist()},'flow_updates':[],
          'flow_outcomes':[],'scope':'same original simulated flight; no multiseed or hardware inference'}
    reports={}
    for run in (args.full_run,args.controls_run):
        suite=json.loads((run/'suite-result.json').read_text());bind(run/'suite-result.json')
        if suite['status']!='PASS':raise ValueError('Incomplete replay suite')
        for entry in suite['arms']:
            mode=entry['mode'];directory=run/mode
            eval_dir=args.full_evaluation if mode=='full' else args.controls_evaluation
            report=json.loads((eval_dir/'report.json').read_text())
            if report['status']!='PASS' or report['arms'][mode]['status']!='PASS':raise ValueError('Independent audit not PASS')
            reports[mode]=report['arms'][mode]
            odometry=list(rows(directory/'odometry.jsonl'))
            metric,trajectory=align_and_measure(odometry,truth,tolerance_s=.015,
                body_transform={'translation_m':[0,0,0],'rotation_xyzw':[0,0,0,1]})
            if metric!=reports[mode]['trajectory_metrics']:raise ValueError('Figure metrics do not reproduce report')
            t=np.asarray([value['stamp_s'] for value in trajectory]);p=np.asarray([value['position'] for value in trajectory])
            errors=[]
            for stamp,position in zip(t,p):
                i=bisect.bisect_left(truth_times,stamp)
                candidates=[index for index in (i-1,i) if 0<=index<len(truth_times)]
                nearest=min(candidates,key=lambda index:abs(truth_times[index]-stamp))
                errors.append(float(np.linalg.norm(position-truth_positions[nearest])))
            if abs(float(np.sqrt(np.mean(np.square(errors))))-metric['ate_rms_m'])>1e-12:
                raise ValueError('Aligned plotting error differs from reported ATE')
            data['arms'][mode]={'stamps_s':t.tolist(),'aligned_positions':p.tolist(),'position_error_m':errors,
                'ate_rms_m':metric['ate_rms_m'],'ate_max_m':metric['ate_max_m']}
            for name in ('odometry.jsonl','joint-updates.jsonl','processing-result.json','publisher-result.json'):
                bind(directory/name)
            bind(eval_dir/'report.json')
            shutil.copy2(eval_dir/'report.json',target/('audit-full.json' if mode=='full' else 'audit-controls.json'))
            if mode=='full':
                for row in rows(directory/'joint-updates.jsonl'):
                    if row['event']=='flow':
                        category='accepted' if row['accepted'] else ('insufficient_translation' if row['reason']=='pure_rotation_or_insufficient_translation' else 'insufficient_tracks')
                        if row['reason'] not in ('joint_nonlinear_update_applied','pure_rotation_or_insufficient_translation','insufficient_or_excessive_tracks'):
                            raise ValueError('Unrepresented flow rejection category')
                        data['flow_outcomes'].append({'stamp_s':row['stamp_ns']*1e-9,'category':category,'reason':row['reason']})
                        if row['accepted']:
                            before=np.asarray(row['state_before']['p']).reshape(3);after=np.asarray(row['state_after']['p']).reshape(3)
                            data['flow_updates'].append({'stamp_s':row['stamp_ns']*1e-9,
                                'position_delta_m':float(np.linalg.norm(after-before)),'nis_per_dof':row['nis']/row['dof']})
                            if 'example_covariance28' not in data:data['example_covariance28']=row['joint_covariance_before']
    if set(data['arms'])!={'native','joint_no_flow','full','zero_gyro','zero_plane'}:raise ValueError('Missing comparison mode')
    data['origin_stamp_s']=min(data['arms']['full']['stamps_s'])
    for path in (args.truth,full_manifest,control_manifest,*indices,args.workspace/'scripts/analyze_livo_replay.py',Path(__file__)):
        bind(path)
    (target/'figure_data.json').write_text(json.dumps(data,separators=(',',':'),allow_nan=False)+'\n')
    (target/'verified_metrics.json').write_text(json.dumps(reports,indent=2,allow_nan=False)+'\n')
    (target/'source_manifest.json').write_text(json.dumps({'sources':sources,
        'same_input_index_and_complete_build_manifest':True,'raw_data_included_in_latex_bundle':False},indent=2)+'\n')
    print(json.dumps({'status':'PASS','arms':list(data['arms']),'actual_full_updates':len(data['flow_updates']),
                      'input_sha256':digest(indices[0])['sha256']}))
if __name__=='__main__':main()
