#!/usr/bin/env python3
"""Read-only numerical and internal-reference review of the working manuscript."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


def load(path):return json.loads(path.read_text())


def fingerprint(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1048576),b''):h.update(block)
    return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}


def main():
    data=load(ROOT/'evidence/figure_data.json');metrics=load(ROOT/'evidence/metrics.json')
    checks={};details={};truth_t=np.asarray(data['truth']['stamps_s']);truth_p=np.asarray(data['truth']['position'])
    checks['original_truth_stamps_strictly_increasing']=bool(np.all(np.diff(truth_t)>0))
    initial=np.median(truth_p[:100],axis=0)
    details['excitation']={'initial_position_reference':'median of first100 original truth poses',
        'max_horizontal_displacement_m':float(np.max(np.linalg.norm(truth_p[:,:2]-initial[:2],axis=1))),
        'vertical_span_m':float(np.ptp(truth_p[:,2]))}
    for mode,values in metrics['arms'].items():
        plot=data['arms'][mode];t=np.asarray(plot['stamps_s']);p=np.asarray(plot['aligned_positions'])
        trajectory=load(Path(values['trajectory_path']))
        checks[mode+'.plotted_trajectory_exactly_evaluator_export']=bool(np.array_equal(t,np.asarray([r['stamp_s'] for r in trajectory])) and
            np.array_equal(p,np.asarray([r['position'] for r in trajectory])))
        right=np.minimum(np.searchsorted(truth_t,t),len(truth_t)-1);left=np.maximum(right-1,0)
        index=np.where(np.abs(truth_t[left]-t)<=np.abs(truth_t[right]-t),left,right)
        errors=np.linalg.norm(p-truth_p[index],axis=1)
        rmse=float(np.sqrt(np.mean(errors**2)));maximum=float(np.max(errors))
        checks[mode+'.plotted_errors_reproduce_source_positions']=bool(np.allclose(errors,plot['position_error_m'],atol=1e-12,rtol=0))
        checks[mode+'.RMS_max_and_millimetre_units_match_table_metrics']=bool(abs(rmse-values['ate_rmse_mm']/1000)<1e-12 and
            abs(maximum-values['ate_max_mm']/1000)<1e-12 and len(t)==1253 and np.max(np.abs(truth_t[index]-t))<=.009000000001)
    full=Path(metrics['arms']['full']['run_dir']);source_flows=[];source_updates=[];priors={};track_counts=[];translation=[]
    with (full/'joint-updates.jsonl').open() as handle:
        for line in handle:
            row=json.loads(line)
            if row['event']=='flow_prior':priors[row['stamp_ns']]=row
            if row['event']!='flow':continue
            category='accepted' if row['accepted'] else ('insufficient_translation' if row['reason']=='pure_rotation_or_insufficient_translation' else 'insufficient_tracks')
            source_flows.append({'stamp_s':row['stamp_ns']*1e-9,'category':category,'reason':row['reason']})
            if row['reason']=='insufficient_or_excessive_tracks':track_counts.append(row['input_tracks'])
            if row['reason']=='pure_rotation_or_insufficient_translation':
                translation.append(float(np.linalg.norm(np.asarray(row['state_before']['p'])-np.asarray(priors[row['stamp_ns']]['clone_p']))))
            if row['accepted']:
                source_updates.append({'stamp_s':row['stamp_ns']*1e-9,
                    'position_delta_m':float(np.linalg.norm(np.asarray(row['state_after']['p'])-np.asarray(row['state_before']['p']))),
                    'nis_per_dof':row['nis']/row['dof']})
                if len(source_updates)==1:checks['diagnostic_covariance_exact_first_accepted_prior']=data['example_covariance28']==row['joint_covariance_before']
    checks['all_123_plotted_outcomes_exact_source_ledger']=source_flows==data['flow_outcomes'] and len(source_flows)==123
    checks['all_37_position_correction_norms_and_NIS_exact_source_ledger']=source_updates==data['flow_updates'] and len(source_updates)==37
    checks['47_gate_rejections_are_small_PREDICTED_body_displacements']=len(translation)==47 and max(translation)<.005
    checks['39_feature_rejections_are_actually_below_8_not_excessive']=len(track_counts)==39 and max(track_counts)<8
    details['rejected_feature_track_count_range']=[min(track_counts),max(track_counts)]
    details['rejected_predicted_translation_m_range']=[min(translation),max(translation)]
    details['full_flow_outcomes']=dict(Counter(row['category'] for row in source_flows))
    p=np.asarray(data['example_covariance28']);sd=np.sqrt(np.maximum(np.diag(p),0));den=sd[:,None]*sd[None,:]
    corr=np.divide(p,den,out=np.zeros_like(p),where=den>0)
    checks['diagnostic_heatmap_is_finite_bounded_correlation']=bool(p.shape==(28,28) and np.isfinite(corr).all() and np.max(np.abs(corr))<=1+1e-8)
    table=(ROOT/'sections/results_table.tex').read_text()
    for mode,row in metrics['arms'].items():
        match=re.search(r'^'+re.escape(row['label'])+r'\s*&\s*(\d+)\s*&\s*([\d.]+)\s*&\s*([\d.]+)\s*&\s*([^\\\n]+)',table,re.M)
        checks[mode+'.current_TeX_table_matches_numeric_metrics']=bool(match and int(match[1])==row['actual_nonzero_state_and_covariance_updates'] and
            abs(float(match[2])-row['ate_rmse_mm'])<=.000500001 and abs(float(match[3])-row['ate_max_mm'])<=.000500001 and
            (match[4].strip()=='--' if row['nis_per_dof_median'] is None else abs(float(match[4])-row['nis_per_dof_median'])<=.000500001))
    tex_paths=sorted(ROOT.glob('sections/*.tex'))+[ROOT/'main.tex',ROOT/'authors.tex']
    text='\n'.join(path.read_text() for path in tex_paths)
    labels=re.findall(r'\\label\{([^}]+)\}',text)
    references=re.findall(r'\\(?:eqref|ref|autoref)\{([^}]+)\}',text)
    keys=set(re.findall(r'@\w+\s*\{\s*([^,]+),',(ROOT/'references.bib').read_text()))
    cites=[part.strip() for group in re.findall(r'\\cite(?:\[[^\]]*\])?\{([^}]+)\}',text) for part in group.split(',')]
    details['duplicate_labels']=[name for name,count in Counter(labels).items() if count>1]
    details['undefined_internal_references']=sorted(set(references)-set(labels))
    details['undefined_citation_keys']=sorted(set(cites)-keys)
    checks['all_labels_unique']=not details['duplicate_labels']
    checks['all_internal_reference_targets_defined']=not details['undefined_internal_references']
    checks['all_citation_keys_defined_in_bibliography']=not details['undefined_citation_keys']
    checks['no_old_conflicting_skew_macro_call']='\\skew{' not in text
    details['missing_graphics']=[name for name in re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}',text) if not (ROOT/'figures'/name).is_file()]
    checks['all_referenced_figure_files_present']=not details['missing_graphics']
    source_files=tex_paths+[ROOT/'evidence/figure_data.json',ROOT/'evidence/metrics.json',ROOT/'make_evidence.py',ROOT/'make_figures.py',ROOT/'references.bib']
    result={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'details':details,
        'paper_source_fingerprints_at_review':{str(p.relative_to(ROOT)):fingerprint(p) for p in source_files},
        'scope':'Working-source and existing-data claim crosscheck only; no experiment, source-fusion edit, database read, ROS node or AP execution. Bibliography key resolution is not an external-literature accuracy review. PDF rendering remains separate.'}
    with (ROOT/'evidence/claim_crosscheck_v1.json').open('x') as handle:json.dump(result,handle,indent=2);handle.write('\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),'failed_checks':[k for k,v in checks.items() if not v],'details':details}))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
