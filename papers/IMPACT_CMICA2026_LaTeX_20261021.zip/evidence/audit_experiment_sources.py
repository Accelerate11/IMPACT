#!/usr/bin/env python3
"""Bind the five completed arms to exact original input rows and build identity.

Read-only JSON/JSONL audit; never imports ROS, opens databases, or starts replay.
Generated files are exclusive so an earlier result cannot be silently replaced.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


PAPER=Path(__file__).resolve().parents[1]
RESULTS=Path('/home/accelerate/impact_research_ws/experiments/results/research_multisensor')
FULL=RESULTS/'joint_livo_integration_20261021T080222Z_530'
CONTROLS=RESULTS/'joint_livo_controls_20261021T080835Z_318'
TRUTH=Path('/mnt/d/CODEX/impact/runs/software_completion_joint_input_index_20261021T074341Z_324/evaluator/truth.jsonl')
ROLES=('imu','lidar','front','down','range')
MODES=('native','joint_no_flow','full','zero_gyro','zero_plane')
LABELS={'native':'Native','joint_no_flow':'Joint/no-flow','full':'Full',
        'zero_gyro':'Zero gyro cross','zero_plane':'Zero plane cross'}


def read(path):return json.loads(path.read_text())


def record(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1048576),b''):h.update(block)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}


def write(path,value):
    with path.open('x') as handle:json.dump(value,handle,indent=2,allow_nan=False);handle.write('\n')


def main():
    paths={TRUTH,Path(__file__),Path('/mnt/d/CODEX/impact/scripts/analyze_joint_livo_replay.py'),
           Path('/mnt/d/CODEX/impact/scripts/analyze_livo_replay.py')}
    runs={mode:FULL if mode=='full' else CONTROLS for mode in MODES}
    indices={run:read(run/'input/sensor-index.json') for run in set(runs.values())}
    index=indices[FULL]
    checks={'same_exact_sensor_index':record(FULL/'input/sensor-index.json')['sha256']==record(CONTROLS/'input/sensor-index.json')['sha256'],
        'same_exact_build_manifest':record(FULL/'configuration/joint-build-manifest.json')['sha256']==record(CONTROLS/'configuration/joint-build-manifest.json')['sha256'],
        'same_declared_experiment_protocol':record(FULL/'configuration/research_joint_livo_replay.json')['sha256']==record(CONTROLS/'configuration/research_joint_livo_replay.json')['sha256']}
    reports={run:read(run/'evaluation_v1/report.json') for run in set(runs.values())}
    expected_evaluator=record(Path('/mnt/d/CODEX/impact/scripts/analyze_joint_livo_replay.py'))
    expected_truth=record(TRUTH)
    source_index_hash=record(FULL/'input/sensor-index.json')['sha256']
    for run in set(runs.values()):
        for relative in ('suite-result.json','input/sensor-index.json','input/pair-profile.json',
            'configuration/joint-build-manifest.json','configuration/research_joint_livo_replay.json',
            'frozen-inputs.before.json','frozen-inputs.after.json','evaluation_v1/report.json'):
            paths.add(run/relative)
        before,after=read(run/'frozen-inputs.before.json'),read(run/'frozen-inputs.after.json')
        checks[str(run.name)+'.frozen_inputs_unchanged']=before==after
        checks[str(run.name)+'.suite_and_evaluation_pass']=read(run/'suite-result.json')['status']=='PASS' and reports[run]['status']=='PASS'
        for role,expected in [('truth',expected_truth),('evaluator',expected_evaluator)]:
            checks[run.name+'.'+role+'_identity']=reports[run]['inputs'][role]=={key:expected[key] for key in ('bytes','sha256')}
    normalized=[];arms={}
    for mode in MODES:
        run=runs[mode];directory=run/mode
        for name in ('publisher-result.json','publication-ledger.jsonl','processing-result.json',
                     'run-result.json','source-files.before.json','source-files.after.json','odometry.jsonl','joint-updates.jsonl'):
            paths.add(directory/name)
        paths.add(run/'evaluation_v1'/(mode+'-trajectory.json'))
        publisher=read(directory/'publisher-result.json');processing=read(directory/'processing-result.json')
        checks[mode+'.publisher_pass_and_payload_identity']=bool(publisher['status']=='PASS' and
            publisher['source_index_sha256']==source_index_hash==publisher['source_index_sha256_after'] and
            publisher['original_acquisition_headers_and_serialized_payloads_preserved'] is True and
            publisher['truth_reference_oldstate_TF_AP_payloads_loaded_or_published'] is False and
            publisher['original_source_family_set_bytes_sha256_unchanged'] is True)
        checks[mode+'.same_original_raw_family_before_after']=read(directory/'source-files.before.json')==read(directory/'source-files.after.json')==index['source_files']
        checks[mode+'.complete_five_sensor_counts_and_tails']=bool(processing['status']=='COMPLETE' and
            processing['all_inputs_received'] and processing['all_image_messages_accounted'] and
            processing['joint_inputs']['all_five_counts_and_tails_verified'] and
            publisher['published_counts']==index['published_sensor_counts'])
        counts=Counter();sensor_position=0;barriers=0;normal=hashlib.sha256()
        with (directory/'publication-ledger.jsonl').open() as handle:
            for line in handle:
                event=json.loads(line)
                if event['event']=='sensor_publication':
                    assert event['source']==index['entries'][sensor_position],(mode,sensor_position)
                    assert event['original_cdr_published_unchanged'] is True
                    counts[event['source']['sensor']]+=1
                    assert event['sensor_publication_sequence']==counts[event['source']['sensor']]
                    sensor_position+=1
                    stable={'event':'sensor_publication','source':event['source'],'sensor_publication_sequence':event['sensor_publication_sequence']}
                elif event['event']=='barrier_publication':
                    assert event['data'][1:]==[counts[role] for role in ROLES]
                    assert event['data'][0]>=index['entries'][sensor_position-1]['stamp_ns']
                    barriers+=1;stable={'event':'barrier_publication','data':event['data']}
                else:raise ValueError('Unexpected publication event: '+event['event'])
                normal.update(json.dumps(stable,sort_keys=True,separators=(',',':')).encode()+b'\n')
        checks[mode+'.every_published_original_source_row_and_payload_hash_exact']=sensor_position==len(index['entries']) and dict(counts)==index['published_sensor_counts']
        normalized.append(normal.hexdigest())
        report=reports[run]['arms'][mode];metric=report['trajectory_metrics'];nis=report['nis_per_dof']
        arms[mode]={'label':LABELS[mode],'run_dir':str(directory),
            'evaluation_report':str(run/'evaluation_v1/report.json'),
            'trajectory_path':str(run/'evaluation_v1'/(mode+'-trajectory.json')),
            'status':report['status'],'trajectory_metrics':metric,
            'ate_rmse_mm':metric['ate_rms_m']*1000,'ate_max_mm':metric['ate_max_m']*1000,
            'actual_nonzero_state_and_covariance_updates':report['actual_nonzero_state_and_covariance_updates'],
            'attempted_frame_pairs':report['attempted_frame_pairs'],
            'flow_reasons':report['flow_reasons'],'range_seed_augmentations':report['range_seed_augmentations'],
            'maximum_jacobian_frobenius_error':report['maximum_jacobian_frobenius_error'],
            'nis_per_dof_median':statistics.median(nis) if nis else None,
            'nis_per_dof_max':max(nis) if nis else None,
            'specified_cross_ablation_batches':report['specified_cross_ablation_batches'],
            'published_sensor_counts':publisher['published_counts'],'processed_images':processing['image_classification_counts']['processed_postVIO'],
            'image_classification':processing['image_classification_counts'],
            'publication_barriers':barriers,'normalized_original_sensor_and_barrier_stream_sha256':normal.hexdigest()}
    checks['all_five_normalized_original_sensor_payload_and_barrier_streams_identical']=len(set(normalized))==1
    assert all(checks.values()),{key:value for key,value in checks.items() if not value}
    before={str(path):record(path) for path in sorted(paths)}
    baseline=arms['joint_no_flow']['trajectory_metrics']['ate_rms_m'];full=arms['full']['trajectory_metrics']['ate_rms_m']
    result={'status':'PASS','independent_flight_recordings':1,'scope':'One original simulated-flight input; descriptive matched-input comparison, not statistical superiority, hardware or AP471 flight validation.',
        'truth_path':str(TRUTH),'source_index_sha256':source_index_hash,
        'build_manifest_sha256':record(FULL/'configuration/joint-build-manifest.json')['sha256'],
        'checks':checks,'arms':arms,'full_minus_primary_control_rms_mm':(full-baseline)*1000,
        'descriptive_full_rms_reduction_percent':100*(baseline-full)/baseline,
        'original_input_acquisition_span_s':(index['entries'][-1]['stamp_ns']-index['entries'][0]['stamp_ns'])*1e-9,
        'alignment':'one first-pair SE3 alignment without scale or global least-squares trajectory fitting',
        'truth_matching':'nearest original truth within 15ms; observed maximum9ms and zero unmatched estimates',
        'no_databases_opened':True,'no_estimator_or_AP_rerun':True}
    write(PAPER/'evidence/metrics.json',result)
    table=['% Generated from evidence/metrics.json; one recorded flight, no significance claim.',
        r'\begin{table}[t]',r'\centering',r'\caption{Matched-input results on one simulated flight. ATE uses one initial SE(3) gauge alignment, without scale fitting. Each row has 1253 matched estimates.}',
        r'\label{tab:results}',r'\setlength{\tabcolsep}{3.3pt}',r'\begin{tabular}{lrrrr}',r'\toprule',
        r'Method & Updates & RMS (mm) & Max (mm) & NIS/DOF$^\dagger$ \\',r'\midrule']
    for mode in MODES:
        row=arms[mode];nis='--' if row['nis_per_dof_median'] is None else f"{row['nis_per_dof_median']:.3f}"
        table.append(f"{row['label']} & {row['actual_nonzero_state_and_covariance_updates']} & {row['ate_rmse_mm']:.3f} & {row['ate_max_mm']:.3f} & {nis} "+r'\\')
    table += [r'\bottomrule',r'\end{tabular}',r'\\[-1pt]{\footnotesize $^\dagger$Median over accepted flow updates; not a calibration test.}',r'\end{table}']
    with (PAPER/'sections/results_table.tex').open('x') as handle:handle.write('\n'.join(table)+'\n')
    after={str(path):record(path) for path in sorted(paths)}
    assert before==after,'Selected source evidence changed during export'
    write(PAPER/'evidence/experiments_source_manifest.json',{'status':'PASS','sources_before':before,'sources_after':after,'all_selected_source_paths_bytes_sha256_unchanged':True,
        'checks':checks,'boundary':'Selected reports, source identities, actual ledgers, trajectories and evaluator helpers only; no SQLite input reads. Publication audit binds every original indexed source row and its payload hash; host publication times are deliberately excluded from the cross-arm stream digest.',
        'generated_outputs':{str(path.relative_to(PAPER)):record(path) for path in [PAPER/'evidence/metrics.json',PAPER/'sections/results_table.tex']}})
    print(json.dumps({'status':'PASS','metrics':str(PAPER/'evidence/metrics.json'),'checks':len(checks),'arms':{mode:{'RMS_mm':entry['ate_rmse_mm'],'max_mm':entry['ate_max_mm']} for mode,entry in arms.items()}}))


if __name__=='__main__':main()
