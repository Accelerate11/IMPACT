# IMPACT / CMICA 2026 论文初稿

这是基于截至 2026-10-21 已完成实验的**英文初稿及完整数学附录**，供讨论和继续修改，不是已提交稿。

本次交付 PDF 共 19 页：正文 5 页、参考文献 1 页、数学与实现附录 13 页，含 108 个编号公式、3 幅图和五组同输入比较。正文使用官网模板。最终 PDF 的所有页面经过渲染检查，公式与实验数值分别作了独立复核；检查记录在 `evidence/`。

## 文件与编辑入口

- `main.tex`：主入口，按顺序加载正文、参考文献和附录。
- `authors.tex`：待补作者英文姓名、单位、通讯邮箱。没有据 GitHub 用户名虚构作者身份。
- `sections/method.tex`：正文算法；`sections/derivations.tex`：完整融合推导。
- `sections/planning_interface.tex`：既有 IMPACT 完整性裕度规划、控制接口及时基公式，明确与新融合尚未联合验证的边界。
- `sections/experiments.tex`：已完成五组同输入比较及其实际结果。
- `references.bib`：可编辑参考文献。
- `figures/`：由实验数据绘制的 PDF 矢量图及 PNG 预览。
- `make_figures.py`、`evidence/figure_data.json`：可重新生成图表。
- `evidence/`：独立评估报告、数值与来源索引；不包含原始大体积 rosbag。
- `IEEEtran.cls`：取自 CMICA 官网下载的 LaTeX 模板，版权说明完整保留。

## 编译

在含完整 TeX Live/MiKTeX 的机器或 Overleaf 上传本目录全部文件，主文件选 `main.tex`。标准编译：

`main.tex` 中将 `\includeappendicestrue` 改为 `\includeappendicesfalse` 可单独编译双栏正文与参考文献。完整附录继续保留在源文件中；最终投稿篇幅仍按会议要求调整。

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

也可依次运行 `pdflatex main`、`bibtex main`、`pdflatex main` 两次。此次实际采用私有目录中的 Tectonic 0.17.0 编译，没有修改机器人仿真的系统依赖：

```sh
tectonic --keep-logs --keep-intermediates main.tex
```

图表重绘需要 Python、NumPy、Matplotlib：

```sh
python make_figures.py
```

`make_evidence.py` 用于从原始研究 workspace 再次导出作图数据；它需要原始记录与评估文件。仅编辑正文、公式或重绘图表无需原始数据库。

## 写作范围

主线是：向真实 FAST-LIVO2 状态接入带克隆位姿和不确定局部平面的原始两视图光流，显式保留模型中的共享 IMU/平面相关项，并做同输入消融。普通 EKF、stochastic cloning、Lucas-Kanade 和 SO(3) reset 都已归功于已有研究，不作为原创。

单段记录的比较不代表多场景统计优越性。正文如实给出全部方法结果，不要求 full 始终最好。像素协方差仍是工程设定，原生地图相关没有恢复，不能把当前高斯协方差直接写成经校准的完整性保护级。

旧 FAST-LIO/AP 仿真记录、新 LIVO 离线融合、AP 4.7.1 无解锁通路验证、目标硬件配置分别说明。没有将旧固件飞行或无解锁收件计数冒充新融合驱动的 AP 4.7.1 闭环实飞。

## 投稿格式与仍需作者确认的内容

官网入口：https://www.cmica.net/ ，投稿说明：https://www.cmica.net/submission/ 。作者已确认目标为 CMICA 2026 Winter，11 月 27–29 日在哈尔滨举办。2026-10-21 查询时页面初稿截止日为 9 月 25 日；本文没有确认延期、发出投稿或联系邮件。作者信息按本轮要求暂不处理。

官网提供 IEEE conference LaTeX 模板。随模板中文清单要求英文正文、双栏正文至少 4 页（不含参考文献）、至少 8 条参考文献并含近三年文献。本文正文采用该模板，**单栏数学附录是内部审阅材料**，投稿前应确认页数、超页费和补充材料规则，按需要拆分或压缩。没有擅自改页边距以压缩篇幅。

作者、单位、通讯邮箱、基金、致谢以及尚未完成的扩展实验需在最终投稿前确认。没有进行查重系统验证或出版社 PDF 格式认证；本地编译和逐页版式检查不能代替这些环节。
