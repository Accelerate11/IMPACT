#!/usr/bin/env python3
"""根据冻结的评估器导出数据生成中文矢量图。

本脚本不生成仿真轨迹。数据 JSON 保存已观测的估计器与评估器记录，
以及对应来源文件的 SHA-256 摘要。
"""
from pathlib import Path
import argparse
import json
import re
import warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.font_manager import FontProperties
from matplotlib.text import Text
from matplotlib.ft2font import FT2Font

ROOT=Path(__file__).resolve().parent
FONT_PATH=next((path for path in (ROOT/'fonts/DroidSansFallbackFull.ttf',
    Path('/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf')) if path.is_file()),None)
if FONT_PATH is None:
    raise FileNotFoundError('缺少随项目提供的 DroidSansFallbackFull.ttf 中文字体')
CJK=FontProperties(fname=str(FONT_PATH))
CJK_CHARACTERS=set(FT2Font(str(FONT_PATH)).get_charmap())
# Matplotlib 3.5 probes the dummy string "lp" to measure every text baseline.
# This CJK-only font has neither glyph. Actual display text is checked below;
# filter only these two synthetic metrics warnings, never a real missing glyph.
warnings.filterwarnings('ignore',message=r'Glyph (108|112) \([lp]\) missing from current font\.',category=UserWarning)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
    'axes.labelsize':8,'legend.fontsize':7,'xtick.labelsize':7,'ytick.labelsize':7,
    'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
    'axes.linewidth':.65,'grid.alpha':.2,'lines.linewidth':1.15,'savefig.dpi':220})
COLORS={'native':'#7c8388','joint_no_flow':'#db8f26','full':'#1767a0',
        'zero_gyro':'#8a5eb2','zero_plane':'#b84c54'}
LABELS={'native':'原生方法','joint_no_flow':'联合模型／禁用光流','full':'完整模型',
        'zero_gyro':'移除陀螺交叉项','zero_plane':'移除平面交叉项'}


def chinese_fonts(fig):
    # DroidSansFallback only supplies CJK glyphs. ASCII panel letters, units,
    # variables and numeric group sizes use mathtext; ordinary numeric ticks
    # retain DejaVu Sans. No data or plotting geometry is changed.
    for artist in fig.findobj(Text):
        if any('\u3000'<=character<='\u9fff' or '\uff00'<=character<='\uffef'
               for character in artist.get_text()):
            literal=re.sub(r'\$[^$]*\$','',artist.get_text())
            missing=[character for character in literal
                     if not character.isspace() and ord(character) not in CJK_CHARACTERS]
            if missing:
                raise ValueError('中文字体缺少实际图中文字：'+repr(missing))
            prop=CJK.copy();prop.set_size(artist.get_fontsize())
            prop.set_weight(artist.get_fontweight());artist.set_fontproperties(prop)


def save(fig,name):
    target=ROOT/'figures';target.mkdir(exist_ok=True)
    fig.savefig(target/(name+'.pdf'),bbox_inches='tight',pad_inches=.035)
    fig.savefig(target/(name+'.png'),bbox_inches='tight',pad_inches=.035)
    plt.close(fig)


def architecture():
    fig,ax=plt.subplots(figsize=(7.16,2.25));ax.set(xlim=(-.12,10.6),ylim=(0,3.45));ax.axis('off')
    def box(x,y,w,h,text,color='#f3f6f8',edge='#5c7382',size=8):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.07,rounding_size=.06',
            facecolor=color,edgecolor=edge,linewidth=.8))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,linespacing=1.5)
    def arrow(a,b,color='#526b7c',style='-'):
        ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=10,color=color,lw=.9,linestyle=style))
    box(.05,2.05,2.6,.95,'激光雷达与惯性测量\n前视相机\n原始采集时间戳')
    box(.05,.35,2.6,1.03,'下视图像与测距\n精确同戳测距种子\n下一原始图像',size=7.5)
    box(3.9,.32,2.65,2.74,'',color='#f8fafb',edge='#1767a0')
    ax.text(5.225,2.87,r'联合状态：$28$维误差',ha='center',va='center',fontweight='bold',fontsize=8.5)
    for y,text,color in [(2.13,r'原生状态：$19$维','#e4edf5'),(1.48,r'位姿克隆：$6$维','#e6f1ea'),(.83,r'局部平面：$3$维','#f8ecdf')]:
        box(4.13,y,2.19,.43,text,color=color,edge='#a4b5c0')
    ax.text(5.225,.5,'保留交叉协方差',ha='center',fontsize=7.5,color='#31546e')
    box(7.85,2.45,2.52,.6,'实际原生里程计',color='#e4edf5',edge='#1767a0')
    box(7.85,1.38,2.52,.6,'独立离线评估器',color='#edf3e8',edge='#5b7750',size=7.6)
    box(7.85,.3,2.52,.6,'真值与测距参考\n仅用于评估',color='#fbf2e5',edge='#a18458',size=7.5)
    arrow((2.75,2.53),(3.8,2.53));arrow((2.75,.86),(3.8,.86))
    ax.text(3.27,2.66,'原生\n更新',ha='center',va='bottom',fontsize=7)
    ax.text(3.27,1.01,'原始像素\n更新',ha='center',va='bottom',fontsize=7)
    arrow((6.65,2.75),(7.75,2.75));arrow((9.11,2.36),(9.11,2.08));arrow((9.11,.99),(9.11,1.28),color='#a18458')
    ax.text(7.2,2.9,r'状态与$P$',ha='center',fontsize=7)
    chinese_fonts(fig);fig.tight_layout(pad=.2);save(fig,'architecture')


def results(data):
    fig,axes=plt.subplots(2,2,figsize=(7.16,4.05));start=data['origin_stamp_s']
    duration=max(data['arms']['full']['stamps_s'])-start
    gt=np.asarray(data['truth']['position']);full=np.asarray(data['arms']['full']['aligned_positions'])
    ax=axes[0,0];ax.plot(gt[:,1],gt[:,2],color='#333333',label='真值',lw=2.,alpha=.6)
    ax.plot(full[:,1],full[:,2],color=COLORS['full'],label='完整模型',lw=1)
    ax.set(xlabel=r'世界坐标$y$（$\mathrm{m}$）',ylabel=r'世界坐标$z$（$\mathrm{m}$）',title=r'$\mathrm{(a)}$记录飞行');ax.grid();ax.legend(loc='lower right')
    ax=axes[0,1]
    for mode in ('native','joint_no_flow','zero_gyro','zero_plane','full'):
        entry=data['arms'][mode];t=np.asarray(entry['stamps_s'])-start
        ax.plot(t,np.asarray(entry['position_error_m'])*1000,color=COLORS[mode],
            label=LABELS[mode],alpha=.95 if mode=='full' else .75,lw=1.4 if mode=='full' else .85)
    ax.set(xlabel=r'首次输出后的采集时间（$\mathrm{s}$）',ylabel=r'位置误差（$\mathrm{mm}$）',
           title=r'$\mathrm{(b)}$相同输入的轨迹误差',yscale='symlog',xlim=(0,duration));ax.set_yscale('symlog',linthresh=1)
    ax.set_yticks([0,1,10,100]);ax.set_yticklabels(['0','1','10','100']);ax.grid()
    ax.legend(ncol=2,loc='upper left',framealpha=.8,columnspacing=.6,handlelength=1.6,fontsize=6)
    updates=data['flow_updates'];ax=axes[1,0]
    ax.scatter([x['stamp_s']-start for x in updates],[x['position_delta_m']*1000 for x in updates],s=13,
        color=COLORS['full'],edgecolors='white',linewidths=.3)
    ax.set(xlabel=r'首次输出后的采集时间（$\mathrm{s}$）',ylabel=r'实际施加的位置修正（$\mathrm{mm}$）',
        title=r'$\mathrm{(c)}$实际接受的光流修正',yscale='log',xlim=(0,duration));ax.grid()
    outcomes=data['flow_outcomes'];ax=axes[1,1]
    order=['accepted','insufficient_translation','insufficient_tracks'];colors=['#247b58','#c79131','#a95b62']
    for j,(reason,color) in enumerate(zip(order,colors)):
        stamps=[x['stamp_s']-start for x in outcomes if x['category']==reason]
        ax.scatter(stamps,[j]*len(stamps),color=color,s=10,marker='|',linewidths=1.1)
    ax.set_yticks(range(3));ax.set_yticklabels(['已接受','预测平移\n过小','轨迹数量\n不足'])
    ax.set(xlabel=r'首次输出后的采集时间（$\mathrm{s}$）',title=r'$\mathrm{(d)}$全部已完成图像对尝试',ylim=(2.5,-.5),xlim=(0,duration))
    ax.grid(axis='x');chinese_fonts(fig);fig.tight_layout(pad=.65,w_pad=.7,h_pad=.9);save(fig,'estimation_results')


def diagnostics(data):
    fig,axes=plt.subplots(1,2,figsize=(7.16,2.7))
    ax=axes[0];updates=data['flow_updates'];start=data['origin_stamp_s']
    ax.scatter([x['stamp_s']-start for x in updates],[x['nis_per_dof'] for x in updates],s=16,color=COLORS['full'])
    ax.set(xlabel=r'首次输出后的采集时间（$\mathrm{s}$）',ylabel=r'$\mathrm{NIS}/$自由度',
        title=r'$\mathrm{(a)}$仅显示被接受的新息',xlim=(0,max(data['arms']['full']['stamps_s'])-start));ax.grid()
    p=np.asarray(data['example_covariance28']);sd=np.sqrt(np.maximum(np.diag(p),0))
    corr=np.divide(p,sd[:,None]*sd[None,:],out=np.zeros_like(p),where=sd[:,None]*sd[None,:]>0)
    ax=axes[1];im=ax.imshow(corr,cmap='RdBu_r',vmin=-1,vmax=1,interpolation='nearest')
    for edge in (18.5,24.5):ax.axhline(edge,color='white',lw=.8);ax.axvline(edge,color='white',lw=.8)
    ax.set_xticks([9,21.5,26]);ax.set_yticks([9,21.5,26]);ax.set_xticklabels([r'原生$19$',r'克隆$6$',r'平面$3$'],fontsize=6.5,rotation=48,ha='right')
    ax.set_yticklabels([r'原生$19$',r'克隆$6$',r'平面$3$'],fontsize=7)
    ax.set_title(r'$\mathrm{(b)}$一次被接受更新之前'+'\n'+'保留的先验相关性')
    fig.colorbar(im,ax=ax,shrink=.75,pad=.025,label='相关系数')
    chinese_fonts(fig);fig.tight_layout(pad=.6,w_pad=1.4);save(fig,'diagnostics')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,default=ROOT/'evidence/figure_data.json')
    args=parser.parse_args();architecture()
    if args.data.exists():
        data=json.loads(args.data.read_text());results(data);diagnostics(data)
    else:print('已生成架构图；结果图仍需冻结的评估器导出数据。')
if __name__=='__main__':main()
