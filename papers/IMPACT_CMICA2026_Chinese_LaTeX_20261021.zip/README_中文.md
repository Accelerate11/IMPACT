# IMPACT / CMICA 2026 完整中文审阅稿

本项目是 2026-10-21 英文初稿的完整对应中文版本，包含正文、完整数学附录、五组同输入实验及 AP 4.7.1 接口说明。正文、图题、坐标和图例均中文化；参考文献保留原文著录。作者信息按要求暂留空。

交付 PDF 共 30 页，保留原稿全部 108 个编号公式。正文与数学附录均完整翻译，并完成逐页视觉检查；85 项翻译不变性核对通过，英文原项目全部 49 个文件的集合、大小及 SHA-256 均保持不变。版本日期沿用英文初稿，实际编译与打包时间另记录在检查清单中。

中文版采用 A4 单栏排版，便于阅读与检查长公式。正式会议英文稿采用官网 IEEE 双栏模板，两种版式不要求页码相同。本文没有添加新实验，也没有将尚未完成的多场景统计、强串联对照或新融合驱动的 AP 4.7.1 完整任务写成已有成果。

## 编辑与编译

- `main.tex` 是入口，`sections/` 包含按章节拆分的全文。
- `sections/method.tex` 是核心算法，`derivations.tex` 是完整融合推导。
- `sections/planning_interface.tex` 是原有规划与执行层的数学定义及 AP 接口，保留其验证范围说明。
- `references.bib`、`main.bbl` 为参考文献；`figures/` 包含矢量 PDF 与 PNG 预览。
- `evidence/figure_data.json` 为真实实验导出的作图数据。`evidence/english_source/` 保存英文稿已有的原始评估报告，不能误当成中文版版式检查。

将**完整目录**上传 Overleaf，编译器选 **XeLaTeX**，主文件选 `main.tex`。本地需要完整 TeX Live 或 MiKTeX（含 `ctex`、`xeCJK`、Fandol 字体及常用数学宏包）：

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

或依次运行 `xelatex main`、`bibtex main`、`xelatex main` 两次。也可运行：

```sh
tectonic --keep-logs --keep-intermediates main.tex
```

本次实际在 WSL 的私有目录中使用 Tectonic 0.17.0 编译，不修改机器人仿真依赖。不要使用 pdfLaTeX 编译中文入口。

`main.tex` 中将 `\includeappendicestrue` 改为 `\includeappendicesfalse`，可仅编译正文与参考文献。附录源文件仍完整保留。

## 图表与可追溯性

重新绘制中文图需要 Python、NumPy、Matplotlib：

```sh
python make_figures.py
```

图中中文采用 `fonts/DroidSansFallbackFull.ttf`，其许可证随附；正文采用 TeX 发行版中的 Fandol 字体。数据与英文稿一致，图表中文化不改变曲线或统计值。`make_evidence.py` 需要原研究环境与原始记录；只编辑论文或重绘已有图无需原始 rosbag。

`evidence/english_source_manifest.json` 记录翻译前英文项目的全部文件身份。中文版核对记录另存于 `evidence/`；最终打包清单记录当前中文项目文件的 SHA-256。英文原稿、原始记录和历史结果保持不变。

正式投稿还需按会议要求准备英文终稿与适当篇幅；本中文版本用于内部审阅和逐式讨论。
