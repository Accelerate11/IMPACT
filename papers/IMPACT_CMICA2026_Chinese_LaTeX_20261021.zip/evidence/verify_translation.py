"""Check translation invariants against the preserved English source project.

Requires only Python's standard library. Run with --english DIR if the English
project is not present next to this Chinese project. Formula prose in \text{}
and alignment-only line breaks are excluded from formula-token comparison.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_text_commands(value):
    while True:
        found = re.search(r'\\text\{', value)
        if not found:
            break
        pos = found.end()
        depth = 1
        while depth and pos < len(value):
            if value[pos] == '{' and value[pos-1] != '\\':
                depth += 1
            elif value[pos] == '}' and value[pos-1] != '\\':
                depth -= 1
            pos += 1
        assert depth == 0
        value = value[:found.start()] + 'TEXTANNOTATION' + value[pos:]
    return value


def normalize(value):
    value = re.sub(r'(?<!\\)%[^\n]*', '', value)
    value = re.sub(r'\\label\{[^}]+\}', '', value)
    value = replace_text_commands(value)
    value = re.sub(r'\\(?:begin|end)\{(?:aligned|split|gather\*?|align\*?|equation\*?)\}', '', value)
    value = re.sub(r'\\\\(?:\[[^\]]*\])?', '', value)
    value = re.sub(r'(?<!\\)&', '', value)
    value = re.sub(r'\\(?:quad|qquad)\b|\\[,!;:]', '', value)
    return re.sub(r'\s+', '', value)


def displays(value):
    expr = r'\\begin\{(?P<kind>equation\*?|align\*?|gather\*?|multline\*?)\}(?P<body>.*?)\\end\{(?P=kind)\}'
    return [normalize(m.group('body')) for m in re.finditer(expr, value, re.S)]


def inline(value):
    return Counter(normalize(m) for m in re.findall(r'(?<!\\)\$(.*?)(?<!\\)\$', value, re.S))


def tokens(command, value):
    return re.findall(r'\\' + command + r'\{([^}]+)\}', value)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--english', type=Path, default=ROOT.parent/'impact_cmica2026_draft_20261021')
    args = parser.parse_args()
    checks = {}
    detail = {}
    for source in sorted((args.english/'sections').glob('*.tex')):
        target = ROOT/'sections'/source.name
        a, b = source.read_text(encoding='utf-8'), target.read_text(encoding='utf-8')
        checks[source.name+'.display_formula_tokens'] = displays(a) == displays(b)
        checks[source.name+'.inline_math_multiset'] = inline(a) == inline(b)
        checks[source.name+'.ordered_labels'] = tokens('label', a) == tokens('label', b)
        for cmd in ('cite', 'ref', 'eqref', 'input'):
            checks[source.name+'.'+cmd] = tokens(cmd,a) == tokens(cmd,b)
        checks[source.name+'.numeric_tokens'] = re.findall(r'\d+(?:\.\d+)?',a) == re.findall(r'\d+(?:\.\d+)?',b)
        checks[source.name+'.contains_full_chinese_prose'] = len(re.findall(r'[\u4e00-\u9fff]',b)) > 30
        detail[source.name] = {'english_sha256':digest(source),'chinese_sha256':digest(target),'display_environments':len(displays(b)), 'inline_math_instances':sum(inline(b).values()), 'labels':len(tokens('label',b))}
    original = json.loads((ROOT/'evidence/english_source_manifest.json').read_text())
    records = original['files']
    checks['english_original_file_set_preserved'] = {p.relative_to(args.english).as_posix() for p in args.english.rglob('*') if p.is_file()} == {r['path'] for r in records}
    checks['english_original_all_sizes_sha256_preserved'] = all((args.english/r['path']).stat().st_size == r['bytes'] and digest(args.english/r['path']) == r['sha256'] for r in records)
    checks['reference_bibliography_unchanged'] = digest(args.english/'references.bib') == digest(ROOT/'references.bib')
    checks['scientific_figure_data_identical'] = digest(args.english/'evidence/figure_data.json') == digest(ROOT/'evidence/figure_data.json')
    result = {'status':'PASS' if all(checks.values()) else 'FAIL', 'checks':checks, 'details':detail, 'scope':'Formula annotations translated; alignment-only wrapping changed in two planning equation groups. Underlying math, all numeric tokens, labels/citations, source data and original English project checked.'}
    output = ROOT/'evidence/translation_invariants_final.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':len(checks),'failures':[k for k,v in checks.items() if not v]},ensure_ascii=False))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
