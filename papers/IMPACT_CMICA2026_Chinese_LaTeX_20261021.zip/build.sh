#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if command -v latexmk >/dev/null 2>&1; then
  latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
elif command -v tectonic >/dev/null 2>&1; then
  tectonic --keep-logs --keep-intermediates main.tex
else
  printf '%s\n' '请安装含中文支持的 TeX Live/MiKTeX，或将完整目录上传 Overleaf，选择 XeLaTeX 和 main.tex。' >&2
  exit 2
fi
